# MZ_SEEK

Stream seek origin enumeration.

|Name|Code|Description|
|-|-|-|
|MZ_SEEK_SET|0|Seek from beginning|
|MZ_SEEK_CUR|1|Seek from current position|
|MZ_SEEK_END|2|Seek from end|